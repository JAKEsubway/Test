public struct Mission(Missions.MissionType type, int goal)
{
	public Missions.MissionType type = type;

	public int goal = goal;
}
