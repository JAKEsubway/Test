using System;

namespace Sensors;

public class Accelerometer
{
	private static bool hasInitialized;

	public static bool init()
	{
		return true;
	}

	public static void raw(ref IntPtr data)
	{
	}

	public static void raw(out AccelData accelData)
	{
		accelData = default;
	}

	public static void terminate()
	{
	}
}
