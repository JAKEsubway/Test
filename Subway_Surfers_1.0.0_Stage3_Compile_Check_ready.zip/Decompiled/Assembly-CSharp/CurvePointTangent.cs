using UnityEngine;

public class CurvePointTangent : MonoBehaviour
{
	public void OnDrawGizmosSelected()
	{
		if (transform.parent != null)
		{
			transform.parent.GetComponent<CurvePoint>().OnDrawGizmosSelected();
		}
	}
}
