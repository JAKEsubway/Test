using System;
using UnityEngine;

[RequireComponent(typeof(Pickup))]
public class CoinMagnetPickup : MonoBehaviour
{
	private Game game;

	private Pickup pickup;

	private void Awake()
	{
		game = Game.Instance;
		this.pickup = GetComponent<Pickup>();
		Pickup pickup = this.pickup;
		pickup.OnPickup = (Pickup.OnPickupDelegate)Delegate.Combine(pickup.OnPickup, new Pickup.OnPickupDelegate(OnPickup));
	}

	private void OnPickup(CharacterPickupParticles particles)
	{
		game.Modifiers.Add(game.Modifiers.CoinMagnet);
		GameStats.Instance.coinMagnetsPickups++;
		particles.PickedUpPowerUp();
	}
}
