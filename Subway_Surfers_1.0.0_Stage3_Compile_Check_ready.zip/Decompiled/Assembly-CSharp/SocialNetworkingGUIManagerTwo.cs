using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SocialNetworkingGUIManagerTwo : MonoBehaviour
{
	private void Start()
	{
		SocialNetworkingManager.facebookReceivedFriends += (ArrayList result) =>
		{
			ResultLogger.logArraylist(result);
		};
		SocialNetworkingManager.facebookReceivedCustomRequest += (object result) =>
		{
			ResultLogger.logObject(result);
		};
	}

	private void OnGUI()
	{
		float num = 5f;
		float num2 = ((Screen.width < 960 && Screen.height < 960) ? 160 : 320);
		float num3 = ((Screen.width < 960 && Screen.height < 960) ? 30 : 70);
		float num4 = num3 + 10f;
		if (GUI.Button(new Rect(5f, num, num2, num3), "Post Message"))
		{
			FacebookBinding.postMessage("im posting this from Unity: " + Time.deltaTime);
		}
		if (GUI.Button(new Rect(5f, num += num4, num2, num3), "Post Message & More"))
		{
			FacebookBinding.postMessageWithLinkAndLinkToImage("link post from Unity: " + Time.deltaTime, "http://prime31.com", "Prime31 Studios", "http://prime31.com/assets/images/prime31logo.png", "Prime31 Logo");
		}
		if (GUI.Button(new Rect(5f, num += num4, num2, num3), "Get Friends"))
		{
			FacebookBinding.graphRequest("me/friends", "GET", new Hashtable { ["fields"] = "id,name,picture" });
		}
		if (GUI.Button(new Rect(5f, num += num4, num2, num3), "Dialog With Options"))
		{
			FacebookBinding.showPostMessageDialogWithOptions("http://prime31.com", "Prime31 Studios", string.Empty, string.Empty);
		}
		if (GUI.Button(new Rect(5f, num += num4, num2, num3), "Custom Feed Dialog"))
		{
			FacebookBinding.showPostMessageDialogWithOptions(new Hashtable
			{
				{ "link", "http://hoodrunner.kiloo.com" },
				{ "picture", "http://prime31.com/assets/images/prime31logo.png" },
				{ "name", "Hood Runner" },
				{ "caption", "New Hood Runner Score" },
				{ "message", "In your face @[671337364:Jeppe]" },
				{ "description", "@[1692528651:Lars] just beat the score of @[671337364:Jeppe] in Hood Runner" }
			});
		}
		if (GUI.Button(new Rect(5f, num += num4 * 2f, num2, num3), "Back"))
		{
			Application.LoadLevel("SocialNetworkingtestScene");
		}
		float x = (float)Screen.width - num2 - 5f;
		num = 5f;
		if (GUI.Button(new Rect(x, num, num2, num3), "Graph Request (me)"))
		{
			FacebookBinding.graphRequest("me", "GET", new Hashtable());
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Post Score"))
		{
			FacebookBinding.graphRequest("me/scores", "GET", new Hashtable { { "score", "2500" } });
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Custom REST Request"))
		{
			FacebookBinding.restRequest("fql.query", "POST", new Hashtable { { "query", "SELECT uid,name FROM user WHERE uid=4" } });
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Custom Dialog"))
		{
			Dictionary<string, string> options = new Dictionary<string, string> { { "message", "Check out this great app!" } };
			FacebookBinding.showDialog("apprequests", options);
		}
	}
}
