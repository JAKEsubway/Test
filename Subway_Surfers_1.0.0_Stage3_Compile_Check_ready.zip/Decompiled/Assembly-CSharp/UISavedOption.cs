using System;
using UnityEngine;

[AddComponentMenu("NGUI/Interaction/Saved Option")]
public class UISavedOption : MonoBehaviour
{
	public string keyName;

	private string key
	{
		get
		{
			if (string.IsNullOrEmpty(keyName))
			{
				return "NGUI State: " + name;
			}
			return keyName;
		}
	}

	private void OnEnable()
	{
		string text = PlayerPrefs.GetString(key);
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		UICheckbox component = GetComponent<UICheckbox>();
		if (component != null)
		{
			component.isChecked = text == "true";
			return;
		}
		UICheckbox[] componentsInChildren = GetComponentsInChildren<UICheckbox>();
		int i = 0;
		for (int num = componentsInChildren.Length; i < num; i++)
		{
			UICheckbox obj = componentsInChildren[i];
			UIEventListener uIEventListener = UIEventListener.Get(obj.gameObject);
			uIEventListener.onClick = (UIEventListener.VoidDelegate)Delegate.Remove(uIEventListener.onClick, new UIEventListener.VoidDelegate(Save));
			obj.isChecked = obj.name == text;
			Debug.Log(text);
			UIEventListener uIEventListener2 = UIEventListener.Get(obj.gameObject);
			uIEventListener2.onClick = (UIEventListener.VoidDelegate)Delegate.Combine(uIEventListener2.onClick, new UIEventListener.VoidDelegate(Save));
		}
	}

	private void OnDisable()
	{
		Save(null);
	}

	private void Save(GameObject go)
	{
		UICheckbox component = GetComponent<UICheckbox>();
		if (component != null)
		{
			PlayerPrefs.SetString(key, (!component.isChecked) ? "false" : "true");
			return;
		}
		UICheckbox[] componentsInChildren = GetComponentsInChildren<UICheckbox>();
		int i = 0;
		for (int num = componentsInChildren.Length; i < num; i++)
		{
			UICheckbox uICheckbox = componentsInChildren[i];
			if (uICheckbox.isChecked)
			{
				PlayerPrefs.SetString(key, uICheckbox.name);
				break;
			}
		}
	}
}
