using UnityEngine;

[AddComponentMenu("GUI/Model Trigger")]
public class ModelTrigger : MonoBehaviour
{
	public enum ModelPosition
	{
		CharacterScreen,
		LoseScreen
	}

	public ModelPosition modelPosition;
}
