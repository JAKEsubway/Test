public class UISlideInCharacterUnlock : UISlideIn
{
	public UILabel CharacterName;

	public void SetupSlideInCharacter(string message)
	{
		gameObject.SetActiveRecursively(state: true);
		CharacterName.text = message.ToUpper();
		SlideIn();
	}
}
