using System;
using System.Collections;
using UnityEngine;

public class pTween
{
	public static IEnumerator To(float duration, float startValue, float endValue, Action<float> callback)
	{
		float time = Time.time;
		float end = time + duration;
		float durationInv = 1f / duration;
		float startMulDurationInv = time / duration;
		for (float time2 = Time.time; time2 < end; time2 = Time.time)
		{
			callback(Mathf.Lerp(startValue, endValue, time2 * durationInv - startMulDurationInv));
			yield return 0;
		}
		callback(endValue);
	}

	public static IEnumerator RealtimeTo(float duration, float startValue, float endValue, Action<float> callback)
	{
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		float end = realtimeSinceStartup + duration;
		float durationInv = 1f / duration;
		float startMulDurationInv = realtimeSinceStartup / duration;
		for (float realtimeSinceStartup2 = Time.realtimeSinceStartup; realtimeSinceStartup2 < end; realtimeSinceStartup2 = Time.realtimeSinceStartup)
		{
			callback(Mathf.Lerp(startValue, endValue, realtimeSinceStartup2 * durationInv - startMulDurationInv));
			yield return 0;
		}
		callback(endValue);
	}

	public static IEnumerator To(float duration, Action<float> callback)
	{
		return To(duration, 0f, 1f, callback);
	}
}
