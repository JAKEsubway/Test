using System.Collections.Generic;
using UnityEngine;

public abstract class Selector : MonoBehaviour
{
	public abstract void PerformSelection(List<GameObject> objectsToVisit);

	public void Awake()
	{
		for (int i = 0; i < transform.childCount; i++)
		{
			transform.GetChild(i).gameObject.SetActiveRecursively(state: false);
		}
	}
}
