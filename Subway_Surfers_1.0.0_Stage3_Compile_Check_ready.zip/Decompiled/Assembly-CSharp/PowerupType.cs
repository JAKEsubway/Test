public enum PowerupType
{
	_notset,
	hoverboard,
	headstart500,
	headstart2000,
	mysterybox,
	jetpack,
	supersneakers,
	coinmagnet,
	letters,
	doubleMultiplier,
	coinpouch,
	skipmission1,
	skipmission2,
	skipmission3
}
