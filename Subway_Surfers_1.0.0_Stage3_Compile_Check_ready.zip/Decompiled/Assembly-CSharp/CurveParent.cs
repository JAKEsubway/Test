using UnityEngine;

public class CurveParent : MonoBehaviour
{
	public Color color = Color.red;

	public void OnDrawGizmos()
	{
		CurvePoint.DrawCurve(transform, color);
	}
}
