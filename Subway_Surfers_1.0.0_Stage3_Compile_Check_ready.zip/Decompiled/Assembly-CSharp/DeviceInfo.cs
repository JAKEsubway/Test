using UnityEngine;

public static class DeviceInfo
{
	public enum FormFactor
	{
		iPhone,
		iPad
	}

	public enum PerformanceLevel
	{
		Low,
		Medium,
		High
	}

	public static string deviceModel;

	public static readonly FormFactor formFactor;

	public static readonly bool isHighres;

	static DeviceInfo()
	{
		deviceModel = SystemInfo.deviceModel;
	}
}
