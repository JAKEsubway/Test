public enum MysteryBoxRewardType
{
	_notset,
	Coins,
	powerup,
	token
}
