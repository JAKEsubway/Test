using UnityEngine;

[AddComponentMenu("NGUI/Interaction/Drag Panel Contents")]
[ExecuteInEditMode]
public class UIDragPanelContents : MonoBehaviour
{
	public UIDraggablePanel draggablePanel;

	[SerializeField]
	[HideInInspector]
	private UIPanel panel;

	private void Awake()
	{
		if (!(panel != null))
		{
			return;
		}
		if (draggablePanel == null)
		{
			draggablePanel = panel.GetComponent<UIDraggablePanel>();
			if (draggablePanel == null)
			{
				draggablePanel = panel.gameObject.AddComponent<UIDraggablePanel>();
			}
		}
		panel = null;
	}

	private void Start()
	{
		if (draggablePanel == null)
		{
			draggablePanel = NGUITools.FindInParents<UIDraggablePanel>(gameObject);
		}
	}

	private void OnPress(bool pressed)
	{
		if (enabled && gameObject.active && draggablePanel != null)
		{
			draggablePanel.Press(pressed);
		}
	}

	private void OnDrag(Vector2 delta)
	{
		if (enabled && gameObject.active && draggablePanel != null)
		{
			draggablePanel.Drag(delta);
		}
	}

	private void OnScroll(float delta)
	{
		if (enabled && gameObject.active && draggablePanel != null)
		{
			draggablePanel.Scroll(delta);
		}
	}
}
