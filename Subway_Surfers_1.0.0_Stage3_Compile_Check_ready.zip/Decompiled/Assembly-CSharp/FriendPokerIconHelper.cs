using UnityEngine;

public class FriendPokerIconHelper : MonoBehaviour
{
	public string highResName;

	private void Start()
	{
		if (DeviceInfo.isHighres)
		{
			GetComponent<UISprite>().spriteName = highResName;
		}
	}
}
