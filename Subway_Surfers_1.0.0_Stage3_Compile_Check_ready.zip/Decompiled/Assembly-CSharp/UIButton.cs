using UnityEngine;

[AddComponentMenu("NGUI/Interaction/Button")]
public class UIButton : UIButtonColor
{
	public bool isEnabled
	{
		get
		{
			Collider component = GetComponent<Collider>();
			if ((bool)component)
			{
				return component.enabled;
			}
			return false;
		}
		set
		{
			Collider component = GetComponent<Collider>();
			if ((bool)component && component.enabled != value)
			{
				component.enabled = value;
				UpdateColor(value, immediate: false);
			}
		}
	}

	protected override void Start()
	{
		base.Start();
		if (!isEnabled)
		{
			UpdateColor(shouldBeEnabled: false, immediate: true);
		}
	}

	private void UpdateColor(bool shouldBeEnabled, bool immediate)
	{
		if ((bool)tweenTarget)
		{
			Color color = defaultColor;
			if (!shouldBeEnabled)
			{
				color.r *= 0.65f;
				color.g *= 0.65f;
				color.b *= 0.65f;
			}
			TweenColor tweenColor = TweenColor.Begin(tweenTarget, 0.15f, color);
			if (immediate)
			{
				tweenColor.color = color;
				tweenColor.enabled = false;
			}
		}
	}
}
