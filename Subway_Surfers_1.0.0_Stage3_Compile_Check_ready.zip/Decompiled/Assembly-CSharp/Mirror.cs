using System;
using UnityEngine;

public class Mirror : MonoBehaviour
{
	private Transform[] children;

	private TrackObject trackObject;

	private void Awake()
	{
		this.trackObject = GetComponent<TrackObject>() ?? gameObject.AddComponent<TrackObject>();
		TrackObject trackObject = this.trackObject;
		trackObject.OnActivate = (TrackObject.OnActivateDelegate)Delegate.Combine(trackObject.OnActivate, new TrackObject.OnActivateDelegate(OnActivate));
		children = new Transform[transform.childCount];
		for (int i = 0; i < transform.childCount; i++)
		{
			children[i] = transform.GetChild(i);
		}
	}

	public void OnActivate()
	{
		int num = UnityEngine.Random.Range(0, 2) * 2 - 1;
		for (int i = 0; i < children.Length; i++)
		{
			Vector3 localPosition = children[i].localPosition;
			localPosition.x *= num;
			children[i].localPosition = localPosition;
		}
	}
}
