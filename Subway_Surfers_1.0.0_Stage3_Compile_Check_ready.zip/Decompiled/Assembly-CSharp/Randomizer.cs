using System.Collections.Generic;
using UnityEngine;

public class Randomizer : Selector
{
	public override void PerformSelection(List<GameObject> objectsToVisit)
	{
		int num = Random.Range(0, transform.childCount);
		for (int i = 0; i < transform.childCount; i++)
		{
			GameObject gameObject = transform.GetChild(i).gameObject;
			if (i == num)
			{
				objectsToVisit.Add(gameObject);
			}
			else
			{
				gameObject.SetActiveRecursively(state: false);
			}
		}
	}
}
