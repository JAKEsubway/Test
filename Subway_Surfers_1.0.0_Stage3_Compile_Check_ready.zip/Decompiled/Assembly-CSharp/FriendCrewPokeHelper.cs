using UnityEngine;

public class FriendCrewPokeHelper : MonoBehaviour
{
	public UISprite zzzIcon;

	public UISprite pokeIcon;

	private Friend _friend;

	public void ActivatePoke(Friend friend)
	{
		_friend = friend;
		NGUITools.AddWidgetCollider(gameObject);
	}

	public void DeactivatePoke()
	{
		Object.Destroy(gameObject.GetComponent<Collider>());
		NGUITools.SetActive(zzzIcon.gameObject, state: false);
		NGUITools.SetActive(pokeIcon.gameObject, state: false);
	}

	private void OnClick()
	{
		DeactivatePoke();
		SocialManager.instance.Poke(_friend);
	}
}
