using UnityEngine;

public class SpiralSpecialCase : MonoBehaviour
{
	public string highResName;

	private void Start()
	{
		if (DeviceInfo.isHighres)
		{
			GetComponent<UITiledSprite>().spriteName = highResName;
		}
	}
}
