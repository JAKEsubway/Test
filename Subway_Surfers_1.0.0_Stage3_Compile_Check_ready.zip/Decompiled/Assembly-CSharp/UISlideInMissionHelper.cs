public class UISlideInMissionHelper : UISlideIn
{
	public UILabel line1;

	public void SetupSlideInMission(string message)
	{
		gameObject.SetActiveRecursively(state: true);
		line1.text = message;
		SlideIn();
	}
}
