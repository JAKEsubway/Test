using UnityEngine;

[AddComponentMenu("GUI/Interaction/Button Message Center")]
public class UIButtonMessageCenter : UIBasicButton
{
	private GameObject target;

	public string functionName;

	protected override void Send()
	{
		if (!enabled || !gameObject.active || string.IsNullOrEmpty(functionName))
		{
			return;
		}
		if (target == null)
		{
			if (MessageCenter.IsInstanced)
			{
				target = MessageCenter.Instance.gameObject;
			}
			else
			{
				Debug.LogError("MessageCenter called but not instanced.");
			}
		}
		Transform[] componentsInChildren = target.GetComponentsInChildren<Transform>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].gameObject.SendMessage(functionName, gameObject, SendMessageOptions.DontRequireReceiver);
		}
	}
}
