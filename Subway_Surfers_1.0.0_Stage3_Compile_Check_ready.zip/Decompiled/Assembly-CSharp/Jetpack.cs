using System;
using System.Collections;
using UnityEngine;

public class Jetpack : CharacterState
{
	[Serializable]
	public class FlyAheadInfo
	{
		public AnimationCurve cameraMovement;
	}

	public delegate void OnStopDelegate();

	public Vector3 cameraOffset = new Vector3(0f, 33f, -33f);

	public float cameraOffsetSmoothDuration = 1f;

	public float cameraAimOffset = 20f;

	public float cameraFOV = 60f;

	public float ySmoothDuration = 0.5f;

	public float speedup = 2f;

	public float flyHeight = 95f;

	public float coinOffset = 200f;

	public float flyAheadDuration = 1.5f;

	private float flyingDuration;

	public float calmDownDuration = 2f;

	public float stopBeforeLandingChunkDistance = 50f;

	public float characterAngle = 45f;

	public float characterChangeTrackLength = 60f;

	public GameObject powerupMesh;

	public AudioClipInfo StartSound;

	public bool headStart;

	public float headStartDistance;

	public float headStartSpeed = 100f;

	public PowerupType powerType;

	public OnStopDelegate OnStop;

	public ActivePowerup Powerup;

	public FlyAheadInfo flyAhead;

	public GameObject JetpackParticles;

	private Game game;

	private Track track;

	private Character character;

	private CharacterController characterController;

	private Transform characterTransform;

	private CharacterCamera characterCamera;

	private Transform characterCameraTransform;

	private Animation characterAnimation;

	public InAirCoinsManager coinsManager;

	private float fuel;

	private float landingZ;

	private float landingTime;

	public AudioStateLoop audioStateLoop;

	public AnimationCurve fisso;

	private static Jetpack instance;

	public override bool PauseActiveModifiers => true;

	public float LandingZ => landingZ;

	public float LandingTime => landingTime;

	public static Jetpack Instance => instance ?? (instance = UnityEngine.Object.FindObjectOfType(typeof(Jetpack)) as Jetpack);

	public void Awake()
	{
		game = Game.Instance;
		track = Track.Instance;
		character = Character.Instance;
		characterController = character.characterController;
		characterTransform = characterController.transform;
		characterCamera = CharacterCamera.Instance;
		characterCameraTransform = characterCamera.transform;
		characterAnimation = character.characterAnimation;
		coinsManager = this.FindObject<InAirCoinsManager>();
		Variable<bool> isInGame = game.isInGame;
		isInGame.OnChange = (Variable<bool>.OnChangeDelegate)Delegate.Combine(isInGame.OnChange, (Variable<bool>.OnChangeDelegate)((bool flag) =>
		{
			if (!flag)
			{
				TurnOffEffects();
			}
		}));
	}

	public override IEnumerator Begin()
	{
		GameStats.Instance.usePowerups++;
		Powerup = GameStats.Instance.TriggerPowerup(powerType);
		audioStateLoop.ChangeLoop(AudioState.Jetpack);
		game.Modifiers.PauseInJetpackMode();
		character.Stumble = false;
		powerupMesh.active = true;
		character.shadow.active = false;
		ChangeAnimations();
		characterAnimation.CrossFade(character.animations.run);
		Vector3 startCameraOffset = characterCameraTransform.position - characterTransform.position;
		float startCameraAimOffset = game.Running.cameraAimOffset;
		float startY = characterTransform.position.y;
		characterController.detectCollisions = false;
		character.characterCollider.enabled = false;
		fuel = 1f;
		new SmoothDampFloat(characterTransform.position.y, ySmoothDuration).Target = flyHeight;
		float jetpackSpeed = ((!headStart) ? (game.currentLevelSpeed * speedup) : headStartSpeed);
		float num = ((!headStart) ? Powerup.timeLeft : (headStartDistance / headStartSpeed));
		float num2 = jetpackSpeed * num;
		float num3 = jetpackSpeed * flyAheadDuration;
		float flyLength = num3 + num2;
		flyLength = track.LayJetpackChunks(character.z, flyLength) - stopBeforeLandingChunkDistance * Game.Instance.NormalizedGameSpeed;
		float num4 = flyLength / jetpackSpeed;
		float extendedFlyDuration = num4 - flyAheadDuration;
		num2 = extendedFlyDuration * jetpackSpeed;
		if (!headStart)
		{
			float length = num2 - coinOffset;
			float startZ = character.z + num3 + coinOffset;
			coinsManager.Spawn(startZ, length, flyHeight);
		}
		else
		{
			So.Instance.playSound(StartSound);
		}
		landingTime = Time.time + num4;
		landingZ = character.z + flyLength;
		float cameraZ = character.z;
		float startTime2 = Time.time;
		float num5 = (Time.time - startTime2) / flyAheadDuration;
		JetpackParticles.SetActiveRecursively(state: true);
		game.currentSpeed = jetpackSpeed;
		Vector3 cameraPositionStart = characterCamera.position;
		Vector3 cameraTargetStart = characterCamera.target;
		Vector3 initRot = JetpackParticles.transform.rotation.eulerAngles;
		Vector3 initScale = JetpackParticles.transform.localScale;
		Debug.DrawLine(cameraPositionStart, cameraTargetStart, Color.red, 1000f);
		while (num5 < 1f)
		{
			game.HandleControls();
			Vector3 vector = Vector3.Lerp(startCameraOffset, cameraOffset, Mathf.SmoothStep(0f, 1f, num5));
			float num6 = Mathf.Lerp(startCameraAimOffset, cameraAimOffset, Mathf.SmoothStep(0f, 1f, num5));
			float num7 = Mathf.Lerp(0f, 1f, fisso.Evaluate(num5));
			character.z += jetpackSpeed * Time.deltaTime;
			Vector3 vector2 = track.GetPosition(character.x, character.z) + Vector3.up * (startY + (flyHeight - startY) * Mathf.SmoothStep(0f, 1f, num5));
			characterTransform.position = vector2;
			cameraZ += ((!headStart) ? game.currentLevelSpeed : jetpackSpeed) * Time.deltaTime;
			Vector3 vector3 = new Vector3(track.GetPosition(character.x, character.z).x, vector2.y, character.z) + vector;
			Vector3 vector4 = vector2 + Vector3.up * num6;
			float t = flyAhead.cameraMovement.Evaluate(num5);
			Vector3 position = Vector3.Lerp(cameraPositionStart, vector3, t);
			Vector3 target = Vector3.Lerp(cameraTargetStart, vector4, t);
			position.x = vector3.x;
			target.x = vector3.x;
			characterCamera.position = position;
			characterCamera.target = target;
			Debug.DrawLine(vector3, vector4, Color.red);
			JetpackParticles.transform.rotation = Quaternion.Euler(initRot - new Vector3(num7 * 1f, 0f, 0f));
			JetpackParticles.transform.localScale = initScale + new Vector3(0f, 0f, num7 * 2f);
			game.UpdateMeters();
			game.LayTrackChunks();
			yield return 0;
			num5 = (Time.time - startTime2) / flyAheadDuration;
		}
		character.characterCollider.enabled = true;
		float width = 200f;
		Debug.DrawLine(Vector3.forward * landingZ + Vector3.left * width, Vector3.forward * landingZ + -Vector3.left * width, Color.red, 100f);
		Debug.DrawLine(Vector3.forward * landingZ + Vector3.left * width, Vector3.forward * landingZ + -Vector3.left * width, Color.blue, 100f);
		startTime2 = Time.time;
		num5 = (Time.time - startTime2) / extendedFlyDuration;
		while (num5 < 1f)
		{
			game.HandleControls();
			character.z += jetpackSpeed * Time.deltaTime;
			character.transform.position = track.GetPosition(character.x, character.z) + Vector3.up * flyHeight;
			Vector3 position2 = character.transform.position;
			characterCamera.position = position2 + cameraOffset;
			characterCamera.target = position2 + Vector3.up * cameraAimOffset;
			game.UpdateMeters();
			game.LayTrackChunks();
			yield return 0;
			num5 = (Time.time - startTime2) / extendedFlyDuration;
			fuel = 1f - num5;
			Debug.DrawLine(Vector3.forward * character.z + Vector3.left * width, Vector3.forward * character.z + -Vector3.left * width, Color.green);
		}
		if (OnStop != null)
		{
			OnStop();
		}
		characterController.detectCollisions = true;
		TurnOffEffects();
		coinsManager.ReleaseCoins();
		game.Modifiers.Resume();
		game.ChangeState(game.Running);
		character.ChangeAnimations();
	}

	private void TurnOffEffects()
	{
		JetpackParticles.SetActiveRecursively(state: false);
		powerupMesh.active = false;
		audioStateLoop.ChangeLoop(AudioState.JetpackStop);
	}

	private void ChangeAnimations()
	{
		character.animations.run = "jetpack_forward";
		character.animations.dodgeLeft = "jetpack_forward";
		character.animations.dodgeRight = "jetpack_forward";
	}

	public override void HandleSwipe(SwipeDir swipeDir)
	{
		switch (swipeDir)
		{
		case SwipeDir.Left:
			character.ChangeTrack(-1, characterChangeTrackLength / game.currentSpeed);
			break;
		case SwipeDir.Right:
			character.ChangeTrack(1, characterChangeTrackLength / game.currentSpeed);
			break;
		case SwipeDir.None:
			break;
		}
	}
}
