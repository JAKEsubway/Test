using System;
using System.Collections;
using UnityEngine;

public class Running : CharacterState
{
	public enum RunPositions
	{
		ground,
		station,
		train,
		movingTrain,
		air
	}

	public float slowDownDuration = 0.625f;

	public float slowDownRatio = 1f;

	public float tunnelDelta = -20f;

	public Vector3 cameraOffset = new Vector3(0f, 33f, -33f);

	public float cameraOffsetSmoothDuration = 0.5f;

	public float cameraAimOffset = 20f;

	public float cameraFOV = 60f;

	public float smoothCameraXDuration = 0.05f;

	public float ySmoothDuration = 0.1f;

	public float characterChangeTrackLength = 30f;

	public AnimationCurve transitionFromJetpackCurve;

	private float tunnelStartZ;

	private Curve offsetDeltaCurve;

	private Game game;

	private Character character;

	private Transform characterTransform;

	private CharacterController characterController;

	private CharacterCamera characterCamera;

	private Transform characterCameraTransform;

	private Animation characterAnimation;

	public Transform spineAnimation;

	private Track track;

	public RunPositions currentRunPosition;

	private static Running instance;

	public static Running Instance => instance ?? (instance = UnityEngine.Object.FindObjectOfType(typeof(Running)) as Running);

	public void Awake()
	{
		game = Game.Instance;
		track = Track.Instance;
		this.character = Character.Instance;
		characterTransform = this.character.transform;
		characterController = this.character.characterController;
		characterCamera = CharacterCamera.Instance;
		characterCameraTransform = characterCamera.transform;
		characterAnimation = this.character.characterAnimation;
		characterAnimation["stumbleCornerLeft"].AddMixingTransform(spineAnimation);
		characterAnimation["stumbleCornerLeft"].layer = 2;
		characterAnimation["stumbleCornerLeft"].weight = 1f;
		characterAnimation["stumbleCornerRight"].AddMixingTransform(spineAnimation);
		characterAnimation["stumbleCornerRight"].layer = 2;
		characterAnimation["stumbleCornerRight"].weight = 1f;
		Character character = this.character;
		character.OnStumble = (Character.OnStumbleDelegate)Delegate.Combine(character.OnStumble, new Character.OnStumbleDelegate(this.character.characterCamera.Shake));
		this.character.OnGrounded += UpdateGroundTag;
	}

	public override IEnumerator Begin()
	{
		bool transitionFromJetpack = characterTransform.position.y > 70f;
		character.characterCollider.enabled = true;
		character.characterCamera.enabled = true;
		SmoothDampVector3 currentCameraOffset = new SmoothDampVector3(cameraOffset, cameraOffsetSmoothDuration)
		{
			Target = cameraOffset
		};
		SmoothDampFloat smoothCameraX = new SmoothDampFloat(characterCameraTransform.position.x, smoothCameraXDuration);
		SmoothDampFloat currentCameraAimOffset = new SmoothDampFloat(cameraAimOffset, cameraOffsetSmoothDuration);
		offsetDeltaCurve = new Curve();
		character.lastGroundedY = character.transform.position.y;
		AnimationEvent evt = new AnimationEvent
		{
			functionName = "SetAnimationSpeedEvent",
			time = 0.1f,
			messageOptions = SendMessageOptions.RequireReceiver
		};
		characterAnimation["run"].clip.AddEvent(evt);
		characterAnimation["run2"].clip.AddEvent(evt);
		characterAnimation["run3"].clip.AddEvent(evt);
		characterAnimation["run4_long"].clip.AddEvent(evt);
		ParticleSystem[] componentsInChildren = character.sprayCanModel.GetComponentsInChildren<ParticleSystem>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].enableEmission = false;
		}
		float transitionTimeMax = 2f;
		float transitionTime = 0f;
		Vector3 cameraPositionStart = characterCamera.position;
		Vector3 cameraTargetStart = characterCamera.target;
		character.fallAnim = false;
		characterController.Move(Vector3.down * 2f);
		character.fallAnim = true;
		character.ChangeAnimations();
		SmoothDampFloat y = new SmoothDampFloat(characterTransform.position.y, ySmoothDuration);
		while (true)
		{
			game.LayTrackChunks();
			game.currentSpeed = game.currentLevelSpeed;
			game.HandleControls();
			character.ApplyGravity();
			character.MoveForward();
			Vector3 position = character.transform.position;
			if (game.Modifiers.IsActive(game.Modifiers.SuperSneakes))
			{
				y.Target = 0.5f * (character.lastGroundedY + position.y);
			}
			else if (characterController.isGrounded)
			{
				y.Target = character.lastGroundedY;
			}
			else if (position.y < character.lastGroundedY)
			{
				y.Target = position.y;
			}
			Vector3 vector = offsetDeltaCurve.Evaluate(character.z - tunnelStartZ);
			smoothCameraX.Target = position.x * 0.75f;
			Vector3 vector2 = new Vector3(smoothCameraX.Value, y.Value, position.z) + currentCameraOffset.Value + vector;
			Vector3 vector3 = new Vector3(smoothCameraX.Value, 0f, position.z) + Vector3.up * (y.Value + currentCameraAimOffset.Value) + vector * 0.5f;
			if (transitionFromJetpack)
			{
				float num = Mathf.Clamp01(transitionTime / transitionTimeMax);
				float t = transitionFromJetpackCurve.Evaluate(num);
				character.characterCamera.position = Vector3.Lerp(cameraPositionStart, vector2, t);
				character.characterCamera.target = Vector3.Lerp(cameraTargetStart, vector3, t);
				if (num == 1f)
				{
					transitionFromJetpack = false;
				}
				transitionTime += Time.deltaTime;
			}
			else
			{
				character.characterCamera.position = vector2;
				character.characterCamera.target = vector3;
			}
			character.CheckInAirJump();
			y.Update();
			currentCameraOffset.Update();
			currentCameraAimOffset.Update();
			smoothCameraX.Update();
			game.UpdateMeters();
			UpdateInAirRunPosition();
			UpdateRunStateMeters();
			yield return 0;
		}
	}

	private void UpdateRunStateMeters()
	{
		float num = game.currentSpeed * Time.deltaTime;
		GameStats gameStats = GameStats.Instance;
		if (currentRunPosition != RunPositions.air)
		{
			if (character.trackIndex == 0)
			{
				gameStats.metersRunLeftTrack += num;
			}
			if (character.trackIndex == 1)
			{
				gameStats.metersRunCenterTrack += num;
			}
			if (character.trackIndex == 2)
			{
				gameStats.metersRunRightTrack += num;
			}
		}
		if (currentRunPosition == RunPositions.ground)
		{
			GameStats.Instance.metersRunGround += num;
		}
		if (currentRunPosition == RunPositions.air)
		{
			GameStats.Instance.metersFly += num;
		}
		if (currentRunPosition == RunPositions.station)
		{
			GameStats.Instance.metersRunStation += num;
		}
		if (currentRunPosition == RunPositions.train)
		{
			GameStats.Instance.metersRunTrain += num;
		}
		if (currentRunPosition == RunPositions.movingTrain)
		{
			GameStats.Instance.metersRunTrain += num;
		}
	}

	private void UpdateInAirRunPosition()
	{
		if (!characterController.isGrounded)
		{
			currentRunPosition = RunPositions.air;
		}
	}

	private void UpdateGroundTag()
	{
		if (Physics.Raycast(new Ray(character.characterRoot.position, -Vector3.up), out var hitInfo))
		{
			switch (hitInfo.collider.tag)
			{
			case "Ground":
				currentRunPosition = RunPositions.ground;
				break;
			case "HitTrain":
				currentRunPosition = RunPositions.train;
				break;
			case "HitMovingTrain":
				currentRunPosition = RunPositions.movingTrain;
				break;
			case "Station":
				currentRunPosition = RunPositions.station;
				break;
			}
		}
	}

	public override void HandleCriticalHit()
	{
		character.characterCamera.Shake();
		game.Die();
	}

	public override void HandleSwipe(SwipeDir swipeDir)
	{
		switch (swipeDir)
		{
		case SwipeDir.Left:
			character.ChangeTrack(-1, characterChangeTrackLength / game.currentSpeed);
			break;
		case SwipeDir.Right:
			character.ChangeTrack(1, characterChangeTrackLength / game.currentSpeed);
			break;
		case SwipeDir.Up:
			character.Jump();
			break;
		case SwipeDir.Down:
			character.Roll();
			break;
		case SwipeDir.None:
			break;
		}
	}

	public override void HandleDoubleTap()
	{
		if (PlayerInfo.Instance.GetUpgradeAmount(PowerupType.hoverboard) > 0 && !game.modifiers.IsActive(game.modifiers.Hoverboard))
		{
			game.Modifiers.Add(game.Modifiers.Hoverboard);
		}
	}

	public void StartTunnel(float tunnelLength)
	{
		tunnelStartZ = character.z;
		offsetDeltaCurve = new Curve();
		offsetDeltaCurve.AddKey(0f, Vector3.zero, -Vector3.up, -Vector3.up);
		offsetDeltaCurve.AddKey(tunnelLength / 2f, Vector3.up * tunnelDelta);
		offsetDeltaCurve.AddKey(tunnelLength, Vector3.zero, Vector3.up * 0.001f, Vector3.up * 0.001f);
	}

	public void EndTunnel()
	{
	}
}
