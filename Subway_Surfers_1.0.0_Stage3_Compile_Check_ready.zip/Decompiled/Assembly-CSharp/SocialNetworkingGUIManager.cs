using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SocialNetworkingGUIManager : MonoBehaviour
{
	public bool useTweetSheet;

	private string screenshotFilename = "someScreeny.png";

	private void Start()
	{
		SocialNetworkingManager.twitterHomeTimelineReceived += (ArrayList result) =>
		{
			ResultLogger.logArraylist(result);
		};
		SocialNetworkingManager.facebookReceivedCustomRequest += (object result) =>
		{
			ResultLogger.logObject(result);
		};
		ScreenCapture.CaptureScreenshot(screenshotFilename);
	}

	private void OnGUI()
	{
		float num = 5f;
		float x = 5f;
		float num2 = ((Screen.width < 960 && Screen.height < 960) ? 160 : 320);
		float num3 = ((Screen.width < 960 && Screen.height < 960) ? 30 : 70);
		float num4 = num3 + 10f;
		if (GUI.Button(new Rect(x, num, num2, num3), "Initialize"))
		{
			FacebookBinding.init("242042899220023");
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Is Logged In?"))
		{
			Debug.Log("Facebook is logged in: " + FacebookBinding.isLoggedIn());
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Login"))
		{
			FacebookBinding.login();
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Logout"))
		{
			FacebookBinding.logout();
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Get User's Name"))
		{
			FacebookBinding.getLoggedinUsersName();
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Post Image"))
		{
			FacebookBinding.postImage(Application.persistentDataPath + "/" + screenshotFilename, "im an image posted from iOS");
		}
		if (GUI.Button(new Rect(x, num += num4 * 2f, num2, num3), "More Facebook..."))
		{
			Application.LoadLevel("SocialNetworkingtestSceneTwo");
		}
		x = (float)Screen.width - num2 - 5f;
		num = 5f;
		if (GUI.Button(new Rect(x, num, num2, num3), "Initialize"))
		{
			TwitterBinding.init("VKV2NMbj7YIEGblD97ZFSw", "z1Wy3GXYL4XS9z9a2YbE4KWF3T0ynAFBwwwxZSYDI");
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Is Logged In?"))
		{
			Debug.Log("Twitter is logged in: " + TwitterBinding.isLoggedIn());
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Logged in Username"))
		{
			string text = TwitterBinding.loggedInUsername();
			Debug.Log("Twitter username: " + text);
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Login with Oauth"))
		{
			TwitterBinding.showOauthLoginDialog();
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Logout"))
		{
			TwitterBinding.logout();
		}
		if (!useTweetSheet)
		{
			if (GUI.Button(new Rect(x, num += num4, num2, num3), "Post Status Update"))
			{
				TwitterBinding.postStatusUpdate("im posting this from Unity: " + Time.deltaTime);
			}
			if (GUI.Button(new Rect(x, num += num4, num2, num3), "Post Status Update + Image"))
			{
				string pathToImage = Application.persistentDataPath + "/" + screenshotFilename;
				TwitterBinding.postStatusUpdate("I'm posting this from Unity with a fancy image: " + Time.deltaTime, pathToImage);
			}
		}
		else
		{
			if (GUI.Button(new Rect(x, num += num4, num2, num3), "Can User Tweet?"))
			{
				Debug.Log("Can the user tweet using the tweet sheet? " + TwitterBinding.canUserTweet());
			}
			if (GUI.Button(new Rect(x, num += num4, num2, num3), "Post Status Update + Image"))
			{
				TwitterBinding.showTweetComposer("I just scored 999999 points dodging trains in Subway Surfers on my iPhone. Check it out: http://redirect.kiloo.com/subwayapp.php", null);
			}
		}
		if (GUI.Button(new Rect(x, num += num4, num2, num3), "Custom Request"))
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("status", "word up with a boogie boogie update");
			TwitterBinding.performRequest("POST", "/statuses/update.json", dictionary);
		}
	}
}
