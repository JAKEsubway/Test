public class UIButtonGame : UIBasicButton
{
	public enum GameMessage
	{
		_notSet,
		StartNewRun,
		RestartFromPause
	}

	public GameMessage messageType;

	protected override void Send()
	{
		if (messageType == GameMessage.StartNewRun)
		{
			if (Game.Instance != null)
			{
				Game.Instance.StartNewRun();
			}
		}
		else
		{
			_ = messageType;
			_ = 2;
		}
	}
}
