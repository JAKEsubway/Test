public class UISlideInMissionSetHelper : UISlideIn
{
	public UILabel line2;

	public void SetupSlideInMissionSet(int multiplier)
	{
		gameObject.SetActiveRecursively(state: true);
		line2.text = "Points x" + multiplier;
		SlideIn();
	}
}
