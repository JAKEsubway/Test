public class UISlideInLettersHelper : UISlideIn
{
	public void SetupLetters()
	{
		gameObject.SetActiveRecursively(state: true);
		SlideIn();
	}
}
