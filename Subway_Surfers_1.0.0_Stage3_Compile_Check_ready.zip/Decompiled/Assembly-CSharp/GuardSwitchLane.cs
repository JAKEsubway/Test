using UnityEngine;

public class GuardSwitchLane : MonoBehaviour
{
	private SmoothDampFloat smoothGuardX;

	public float guardXSmoothTime = 1f;

	public GameObject character;

	private Vector3 initPos;

	private void Start()
	{
	}

	private void Update()
	{
		Vector3 position = character.transform.position;
		gameObject.transform.position = new Vector3(position.x, position.y, gameObject.transform.position.z);
	}
}
