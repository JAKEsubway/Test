public class SuperSneakersGroup : Group
{
}
