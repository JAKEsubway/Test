using System;
using UnityEngine;

public class UIDailyTimer : MonoBehaviour
{
	private UILabel _timerLabel;

	private void Start()
	{
		_timerLabel = GetComponent<UILabel>();
		DailyWord.Instance.ForceSync();
	}

	private void Update()
	{
		TimeSpan timeSpan = PlayerInfo.Instance.dailyWordExpireTime - DateTime.UtcNow;
		if (timeSpan.Ticks > 0)
		{
			_timerLabel.text = $"Time: {timeSpan.Hours:00}:{timeSpan.Minutes:00}:{timeSpan.Seconds:00}";
		}
		else
		{
			_timerLabel.text = "Time: 00:00:00";
		}
	}
}
