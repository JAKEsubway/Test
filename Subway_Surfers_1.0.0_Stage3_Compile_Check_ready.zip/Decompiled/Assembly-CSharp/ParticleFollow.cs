using UnityEngine;

public class ParticleFollow : MonoBehaviour
{
	public Transform Target;

	public float TweenTime;

	private float tweenVelocity;

	private Vector3 baseRotation;

	private Vector3 baseTargetRotation;

	private Vector3 baseScale;

	private float tweenRotVelocity;

	public float SineOffset;

	public float SineSpeed;

	public float RotationTweenTime;

	private void Awake()
	{
		baseRotation = transform.localEulerAngles;
		baseTargetRotation = Target.localEulerAngles;
		baseScale = transform.localScale;
		gameObject.SetActiveRecursively(state: false);
	}

	private void LateUpdate()
	{
		_ = transform.position;
		_ = Target.position;
		Vector3 position = Target.position;
		position.x = transform.position.x;
		float num = Mathf.SmoothDamp(position.x, Target.position.x, ref tweenVelocity, TweenTime);
		if (!float.IsNaN(num))
		{
			position.x = num;
		}
		transform.position = position;
		_ = baseRotation;
		_ = Target.localEulerAngles;
		Vector3 localEulerAngles = baseRotation;
		localEulerAngles.y = Mathf.SmoothDampAngle(localEulerAngles.y, Target.localEulerAngles.y, ref tweenRotVelocity, RotationTweenTime);
		float num2 = Mathf.Sin(SineOffset + Time.time * SineSpeed) * 5.5f;
		localEulerAngles.y += num2;
		transform.localEulerAngles = localEulerAngles;
	}
}
