using UnityEngine;

public class Cloud : MonoBehaviour
{
	private Transform cameraTransform;

	private void Awake()
	{
		cameraTransform = Camera.main.transform;
	}

	private void OnBecameVisible()
	{
		enabled = true;
	}

	private void Update()
	{
		transform.rotation = cameraTransform.rotation;
	}

	private void OnBecameInvisible()
	{
		enabled = false;
	}
}
