using System;
using System.Collections;
using UnityEngine;

public class SocialNetworkingManager : MonoBehaviour
{
	public static event Action twitterLogin;

	public static event Action<string> twitterLoginFailed;

	public static event Action twitterPost;

	public static event Action<string> twitterPostFailed;

	public static event Action<ArrayList> twitterHomeTimelineReceived;

	public static event Action<string> twitterHomeTimelineFailed;

	public static event Action<object> twitterRequestDidFinishEvent;

	public static event Action<string> twitterRequestDidFailEvent;

	public static event Action facebookLogin;

	public static event Action<string> facebookLoginFailed;

	public static event Action facebookDidLogoutEvent;

	public static event Action<DateTime> facebookDidExtendTokenEvent;

	public static event Action facebookSessionInvalidatedEvent;

	public static event Action<string> facebookReceivedUsername;

	public static event Action<string> facebookUsernameRequestFailed;

	public static event Action facebookPost;

	public static event Action<string> facebookPostFailed;

	public static event Action<ArrayList> facebookReceivedFriends;

	public static event Action<string> facebookFriendRequestFailed;

	public static event Action facebookDialogCompleted;

	public static event Action<string> facebookDialogFailed;

	public static event Action facebookDialogDidntComplete;

	public static event Action<string> facebookDialogCompletedWithUrl;

	public static event Action<object> facebookReceivedCustomRequest;

	public static event Action<string> facebookCustomRequestFailed;

	private void Awake()
	{
		gameObject.name = GetType().ToString();
		UnityEngine.Object.DontDestroyOnLoad(this);
	}

	public void twitterLoginSucceeded(string empty)
	{
		if (twitterLogin != null)
		{
			twitterLogin();
		}
	}

	public void twitterLoginDidFail(string error)
	{
		if (twitterLoginFailed != null)
		{
			twitterLoginFailed(error);
		}
	}

	public void twitterPostSucceeded(string empty)
	{
		if (twitterPost != null)
		{
			twitterPost();
		}
	}

	public void twitterPostDidFail(string error)
	{
		if (twitterPostFailed != null)
		{
			twitterPostFailed(error);
		}
	}

	public void twitterHomeTimelineDidFail(string error)
	{
		if (twitterHomeTimelineFailed != null)
		{
			twitterHomeTimelineFailed(error);
		}
	}

	public void twitterHomeTimelineDidFinish(string results)
	{
		if (twitterHomeTimelineReceived != null)
		{
			ArrayList obj = (ArrayList)MiniJSON.jsonDecode(results);
			twitterHomeTimelineReceived(obj);
		}
	}

	public void twitterRequestDidFinish(string results)
	{
		if (twitterRequestDidFinishEvent != null)
		{
			twitterRequestDidFinishEvent(MiniJSON.jsonDecode(results));
		}
	}

	public void twitterRequestDidFail(string error)
	{
		if (twitterRequestDidFailEvent != null)
		{
			twitterRequestDidFailEvent(error);
		}
	}

	public void facebookLoginSucceeded(string empty)
	{
		if (facebookLogin != null)
		{
			facebookLogin();
		}
	}

	public void facebookLoginDidFail(string error)
	{
		if (facebookLoginFailed != null)
		{
			facebookLoginFailed(error);
		}
	}

	public void facebookDidLogout(string empty)
	{
		if (facebookDidLogoutEvent != null)
		{
			facebookDidLogoutEvent();
		}
	}

	public void facebookDidExtendToken(string secondsSinceEpoch)
	{
		if (facebookDidExtendTokenEvent != null)
		{
			double value = double.Parse(secondsSinceEpoch);
			DateTime obj = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(value);
			facebookDidExtendTokenEvent(obj);
		}
	}

	public void facebookSessionInvalidated(string empty)
	{
		if (facebookSessionInvalidatedEvent != null)
		{
			facebookSessionInvalidatedEvent();
		}
	}

	public void facebookDidReceiveUsername(string username)
	{
		if (facebookReceivedUsername != null)
		{
			facebookReceivedUsername(username);
		}
	}

	public void facebookUsernameRequestDidFail(string error)
	{
		if (facebookUsernameRequestFailed != null)
		{
			facebookUsernameRequestFailed(error);
		}
	}

	public void facebookPostSucceeded(string empty)
	{
		if (facebookPost != null)
		{
			facebookPost();
		}
	}

	public void facebookPostDidFail(string error)
	{
		if (facebookPostFailed != null)
		{
			facebookPostFailed(error);
		}
	}

	public void facebookDidReceiveFriends(string jsonResult)
	{
		if (facebookReceivedFriends != null)
		{
			Hashtable hashtable = (Hashtable)MiniJSON.jsonDecode(jsonResult);
			if (hashtable.Contains("data"))
			{
				facebookReceivedFriends((ArrayList)hashtable["data"]);
			}
			else
			{
				facebookReceivedFriends(new ArrayList());
			}
		}
	}

	public void facebookFriendRequestDidFail(string error)
	{
		if (facebookFriendRequestFailed != null)
		{
			facebookFriendRequestFailed(error);
		}
	}

	public void facebookDialogDidComplete(string empty)
	{
		if (facebookDialogCompleted != null)
		{
			facebookDialogCompleted();
		}
	}

	public void facebookDialogDidCompleteWithUrl(string url)
	{
		if (facebookDialogCompletedWithUrl != null)
		{
			facebookDialogCompletedWithUrl(url);
		}
	}

	public void facebookDialogDidNotComplete(string empty)
	{
		if (facebookDialogDidntComplete != null)
		{
			facebookDialogDidntComplete();
		}
	}

	public void facebookDialogDidFailWithError(string error)
	{
		if (facebookDialogFailed != null)
		{
			facebookDialogFailed(error);
		}
	}

	public void facebookDidReceiveCustomRequest(string result)
	{
		if (facebookReceivedCustomRequest != null)
		{
			object obj = MiniJSON.jsonDecode(result);
			facebookReceivedCustomRequest(obj);
		}
	}

	public void facebookCustomRequestDidFail(string error)
	{
		if (facebookCustomRequestFailed != null)
		{
			facebookCustomRequestFailed(error);
		}
	}
}
